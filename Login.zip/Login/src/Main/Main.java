/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import javax.swing.JOptionPane;

/**
 *
 * @author Miguel
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Usuario mUsuario = new Usuario();
        //METODO PARA PEIDR Y ASIGNAR EL NUMERO DE CONTROL
        mUsuario.setNumControl(JOptionPane.showInputDialog(null, "Ingresa el número de control"));
        //METODO PARA MOSTRAR EL NUMERO DE CONTROL
        JOptionPane.showMessageDialog(null, mUsuario.getNumControl());
        //METODO PARA INGRESAR LA CONTRASEÑA
        mUsuario.setContraseña(JOptionPane.showInputDialog(null, "Ingresa una contraseña"));
        //METODO PARA MOSTRAR LA CONTRASEÑA
        JOptionPane.showMessageDialog(null, mUsuario.getContraseña());
    }
    
}
